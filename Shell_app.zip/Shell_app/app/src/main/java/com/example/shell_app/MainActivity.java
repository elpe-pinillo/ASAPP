package com.example.shell_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Button commandButton = (Button) findViewById(R.id.CommandButton);
        final TextView commandText = (TextView) findViewById(R.id.commandText);
        final TextView outputCommand = (TextView) findViewById(R.id.outputCommand);

        commandButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Process command = null;
                try {
                    command = Runtime.getRuntime().exec(commandText.getText().toString());
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(command.getInputStream()));

                    int read;
                    char[] buffer = new char[4096];
                    StringBuffer output = new StringBuffer();
                    while ((read = bufferedReader.read(buffer)) > 0) {
                        output.append(buffer, 0, read);
                    }
                    bufferedReader.close();
                    // Waits for the command to finish.
                    command.waitFor();
                    outputCommand.setText("Ouput: " + output.toString());

                } catch (IOException | InterruptedException e) {
                    e.printStackTrace();
                    int duration = Toast.LENGTH_LONG;
                    Toast toast = Toast.makeText(getApplicationContext(), e.toString(), duration);
                }


            }
        });


    }



}